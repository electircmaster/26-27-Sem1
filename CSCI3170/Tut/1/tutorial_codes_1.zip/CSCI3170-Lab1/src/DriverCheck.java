/**
 * DriverCheck is a simple utility class used to verify that the
 * Oracle JDBC driver is available on the classpath (or module path)
 * at runtime.
 *
 * <p>It attempts to load the Oracle JDBC driver class by name using
 * reflection. If the class is found, a confirmation message is printed.
 * Otherwise, an error message with a hint for fixing the problem is shown.</p>
 */
public class DriverCheck {

    /**
     * Application entry point.
     *
     * <p>Tries to load the {@code oracle.jdbc.OracleDriver} class via
     * {@link Class#forName(String)}. This triggers the driver's static
     * initializer block, which registers the driver with
     * {@link java.sql.DriverManager}.</p>
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        try {
            // Attempt to load and initialize the Oracle JDBC driver class.
            // If successful, the driver registers itself with DriverManager.
            Class<?> driver = Class.forName("oracle.jdbc.OracleDriver");

            // Print the fully qualified name of the successfully loaded driver.
            System.out.println("Oracle JDBC driver loaded: "
                    + driver.getName());
        } catch (ClassNotFoundException e) {
            // The driver class could not be located on the classpath/module path.
            System.err.println("Oracle JDBC driver was not found.");

            // Provide guidance on how to resolve the missing dependency.
            System.err.println("Add ojdbc17.jar to the module dependencies.");
        }
    }
}