public class HelloDatabase {
    public static void main(String[] args){
        System.out.println("CSCI 3170 Java environment is ready.");
    }
}
